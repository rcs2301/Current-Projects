This is an empty directory to satisfy the weird directory requirements in `build.xml`.
